﻿param(
  [string]$ResourcesPath = "C:\Program Files\Kimi Code\resources"
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Original = Join-Path $Root "original"
$Manifest = Get-Content -Raw -Encoding UTF8 (Join-Path $Root "hashes.json") | ConvertFrom-Json
$Files = $Manifest.files.PSObject.Properties.Name

if (-not (Test-Path -LiteralPath (Join-Path $ResourcesPath "app.asar"))) {
  throw "Kimi Code не найден: $ResourcesPath"
}

function Get-Sha256([string]$Path) {
  return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
}

foreach ($Relative in $Files) {
  $Source = Join-Path $Original $Relative
  $Target = Join-Path $ResourcesPath $Relative
  if (-not (Test-Path -LiteralPath $Source) -or -not (Test-Path -LiteralPath $Target)) {
    throw "Файл не найден: $Relative"
  }
  if ((Get-Sha256 $Source) -ne $Manifest.files.PSObject.Properties[$Relative].Value.original) {
    throw "Оригинальный файл в пакете повреждён: $Relative"
  }
}

foreach ($Relative in $Files) {
  $Source = Join-Path $Original $Relative
  $Target = Join-Path $ResourcesPath $Relative
  Copy-Item -LiteralPath $Source -Destination $Target -Force
  if ((Get-Sha256 $Target) -ne $Manifest.files.PSObject.Properties[$Relative].Value.original) {
    throw "Ошибка проверки после восстановления: $Relative"
  }
  Write-Output "Восстановлено: $Relative"
}

Write-Output "Оригинальные файлы восстановлены. Перезапустите Kimi Code."
