﻿param(
  [string]$ResourcesPath = "C:\Program Files\Kimi Code\resources"
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Payload = Join-Path $Root "payload"
$Manifest = Get-Content -Raw -Encoding UTF8 (Join-Path $Root "hashes.json") | ConvertFrom-Json
$Files = $Manifest.files.PSObject.Properties.Name

if (-not (Test-Path -LiteralPath (Join-Path $ResourcesPath "app.asar"))) {
  throw "Kimi Code не найден: $ResourcesPath"
}

function Get-Sha256([string]$Path) {
  return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
}

foreach ($Relative in $Files) {
  $Entry = $Manifest.files.PSObject.Properties[$Relative].Value
  $Source = Join-Path $Payload $Relative
  $Target = Join-Path $ResourcesPath $Relative
  if (-not (Test-Path -LiteralPath $Source)) {
    throw "В пакете отсутствует файл: $Relative"
  }
  if (-not (Test-Path -LiteralPath $Target)) {
    throw "В установке Kimi Code отсутствует файл: $Relative. Поддерживается только версия 1.4.2."
  }
  if ((Get-Sha256 $Source) -ne $Entry.patched) {
    throw "Файл пакета повреждён: $Relative"
  }
  $CurrentHash = Get-Sha256 $Target
  $Allowed = @($Entry.original, $Entry.patched) + @($Entry.previous)
  if ($Allowed -notcontains $CurrentHash) {
    throw "Неизвестная версия файла: $Relative. Пакет рассчитан на Kimi Code 1.4.2; изменения не внесены."
  }
}

foreach ($Relative in $Files) {
  $Source = Join-Path $Payload $Relative
  $Target = Join-Path $ResourcesPath $Relative
  Copy-Item -LiteralPath $Source -Destination $Target -Force
  if ((Get-Sha256 $Target) -ne $Manifest.files.PSObject.Properties[$Relative].Value.patched) {
    throw "Ошибка проверки после копирования: $Relative"
  }
  Write-Output "Установлено: $Relative"
}

Write-Output "Русификация установлена. Полностью закройте и снова откройте Kimi Code."
