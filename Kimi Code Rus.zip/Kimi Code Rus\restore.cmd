@echo off
chcp 65001 >nul
title Восстановление Kimi Code
net session >nul 2>&1
if errorlevel 1 (
  echo Запрос прав администратора...
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0restore.ps1" > "%~dp0restore-log.txt" 2>&1
if errorlevel 1 (
  type "%~dp0restore-log.txt"
  echo.
  echo Ошибка восстановления. Подробности сохранены в restore-log.txt.
  pause
  exit /b 1
)
type "%~dp0restore-log.txt"
echo.
pause
