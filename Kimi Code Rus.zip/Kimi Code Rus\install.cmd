@echo off
chcp 65001 >nul
title Установка Kimi Code Rus
net session >nul 2>&1
if errorlevel 1 (
  echo Запрос прав администратора...
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" > "%~dp0install-log.txt" 2>&1
if errorlevel 1 (
  type "%~dp0install-log.txt"
  echo.
  echo Ошибка установки. Подробности сохранены в install-log.txt.
  pause
  exit /b 1
)
type "%~dp0install-log.txt"
echo.
pause
